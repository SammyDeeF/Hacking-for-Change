﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.txtRand = New System.Windows.Forms.TextBox()
        Me.txtInput = New System.Windows.Forms.RichTextBox()
        Me.Coaltxt = New System.Windows.Forms.TextBox()
        Me.etctxt = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.CoalTime = New System.Windows.Forms.RichTextBox()
        Me.CoalEffect = New System.Windows.Forms.RichTextBox()
        Me.CoalCost = New System.Windows.Forms.RichTextBox()
        Me.SolarCost = New System.Windows.Forms.RichTextBox()
        Me.SolarEffect = New System.Windows.Forms.RichTextBox()
        Me.SolarTime = New System.Windows.Forms.RichTextBox()
        Me.OtherCost = New System.Windows.Forms.RichTextBox()
        Me.OtherEffect = New System.Windows.Forms.RichTextBox()
        Me.OtherTime = New System.Windows.Forms.RichTextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.SuspendLayout()
        '
        'txtRand
        '
        Me.txtRand.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.txtRand.Location = New System.Drawing.Point(42, 42)
        Me.txtRand.Multiline = True
        Me.txtRand.Name = "txtRand"
        Me.txtRand.Size = New System.Drawing.Size(67, 33)
        Me.txtRand.TabIndex = 0
        Me.txtRand.Text = "Input:"
        '
        'txtInput
        '
        Me.txtInput.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtInput.Location = New System.Drawing.Point(149, 27)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(232, 48)
        Me.txtInput.TabIndex = 1
        Me.txtInput.Text = ""
        '
        'Coaltxt
        '
        Me.Coaltxt.Font = New System.Drawing.Font("Tahoma", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Coaltxt.Location = New System.Drawing.Point(378, 184)
        Me.Coaltxt.Multiline = True
        Me.Coaltxt.Name = "Coaltxt"
        Me.Coaltxt.Size = New System.Drawing.Size(52, 33)
        Me.Coaltxt.TabIndex = 2
        Me.Coaltxt.Text = "Coal"
        Me.Coaltxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etctxt
        '
        Me.etctxt.Font = New System.Drawing.Font("Tahoma", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.etctxt.Location = New System.Drawing.Point(75, 188)
        Me.etctxt.Multiline = True
        Me.etctxt.Name = "etctxt"
        Me.etctxt.Size = New System.Drawing.Size(145, 33)
        Me.etctxt.TabIndex = 4
        Me.etctxt.Text = "Type of Energy"
        Me.etctxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(149, 81)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(232, 46)
        Me.TextBox1.TabIndex = 5
        Me.TextBox1.Text = "Type the amount of energy you want to convert for in kilowatt per day (kWd)"
        '
        'CoalTime
        '
        Me.CoalTime.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CoalTime.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CoalTime.Location = New System.Drawing.Point(325, 234)
        Me.CoalTime.Name = "CoalTime"
        Me.CoalTime.ReadOnly = True
        Me.CoalTime.Size = New System.Drawing.Size(156, 36)
        Me.CoalTime.TabIndex = 6
        Me.CoalTime.Text = ""
        '
        'CoalEffect
        '
        Me.CoalEffect.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CoalEffect.Location = New System.Drawing.Point(325, 287)
        Me.CoalEffect.Name = "CoalEffect"
        Me.CoalEffect.ReadOnly = True
        Me.CoalEffect.Size = New System.Drawing.Size(156, 38)
        Me.CoalEffect.TabIndex = 7
        Me.CoalEffect.Text = ""
        '
        'CoalCost
        '
        Me.CoalCost.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CoalCost.Location = New System.Drawing.Point(325, 336)
        Me.CoalCost.Name = "CoalCost"
        Me.CoalCost.ReadOnly = True
        Me.CoalCost.Size = New System.Drawing.Size(156, 35)
        Me.CoalCost.TabIndex = 8
        Me.CoalCost.Text = ""
        '
        'SolarCost
        '
        Me.SolarCost.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.SolarCost.Location = New System.Drawing.Point(542, 336)
        Me.SolarCost.Name = "SolarCost"
        Me.SolarCost.ReadOnly = True
        Me.SolarCost.Size = New System.Drawing.Size(156, 35)
        Me.SolarCost.TabIndex = 11
        Me.SolarCost.Text = ""
        '
        'SolarEffect
        '
        Me.SolarEffect.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.SolarEffect.Location = New System.Drawing.Point(542, 287)
        Me.SolarEffect.Name = "SolarEffect"
        Me.SolarEffect.ReadOnly = True
        Me.SolarEffect.Size = New System.Drawing.Size(156, 38)
        Me.SolarEffect.TabIndex = 10
        Me.SolarEffect.Text = ""
        '
        'SolarTime
        '
        Me.SolarTime.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.SolarTime.Location = New System.Drawing.Point(542, 234)
        Me.SolarTime.Name = "SolarTime"
        Me.SolarTime.ReadOnly = True
        Me.SolarTime.Size = New System.Drawing.Size(156, 36)
        Me.SolarTime.TabIndex = 9
        Me.SolarTime.Text = ""
        '
        'OtherCost
        '
        Me.OtherCost.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.OtherCost.Location = New System.Drawing.Point(64, 344)
        Me.OtherCost.Name = "OtherCost"
        Me.OtherCost.Size = New System.Drawing.Size(177, 35)
        Me.OtherCost.TabIndex = 14
        Me.OtherCost.Text = "Cost (US dollars):"
        '
        'OtherEffect
        '
        Me.OtherEffect.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.OtherEffect.Location = New System.Drawing.Point(64, 285)
        Me.OtherEffect.Name = "OtherEffect"
        Me.OtherEffect.Size = New System.Drawing.Size(177, 41)
        Me.OtherEffect.TabIndex = 13
        Me.OtherEffect.Text = "Environmental Impact (lbs CO2/mWh per month)"
        '
        'OtherTime
        '
        Me.OtherTime.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.OtherTime.Location = New System.Drawing.Point(64, 231)
        Me.OtherTime.Name = "OtherTime"
        Me.OtherTime.Size = New System.Drawing.Size(177, 36)
        Me.OtherTime.TabIndex = 12
        Me.OtherTime.Text = "Time to produce (units)"
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Tahoma", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.TextBox2.Location = New System.Drawing.Point(592, 191)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(52, 33)
        Me.TextBox2.TabIndex = 15
        Me.TextBox2.Text = "Solar"
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnConvert
        '
        Me.btnConvert.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnConvert.Location = New System.Drawing.Point(477, 27)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(221, 38)
        Me.btnConvert.TabIndex = 16
        Me.btnConvert.Text = "Convert"
        Me.btnConvert.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Tahoma", 13.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnClear.Location = New System.Drawing.Point(541, 88)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(103, 33)
        Me.btnClear.TabIndex = 18
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Segoe UI", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBox4.Location = New System.Drawing.Point(12, 418)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(785, 20)
        Me.TextBox4.TabIndex = 20
        Me.TextBox4.Text = "Disclaimer: these values are not exact as each source has a different equation, b" &
    "ut these are used as a basis to compare the two types of energy, datat is also r" &
    "ounded to the nearest 2 decimal places"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(503, 391)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(245, 15)
        Me.LinkLabel1.TabIndex = 21
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "https://save-with-solar.shohinisarkar.repl.co/"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.OtherCost)
        Me.Controls.Add(Me.OtherEffect)
        Me.Controls.Add(Me.OtherTime)
        Me.Controls.Add(Me.SolarCost)
        Me.Controls.Add(Me.SolarEffect)
        Me.Controls.Add(Me.SolarTime)
        Me.Controls.Add(Me.CoalCost)
        Me.Controls.Add(Me.CoalEffect)
        Me.Controls.Add(Me.CoalTime)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.etctxt)
        Me.Controls.Add(Me.Coaltxt)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.txtRand)
        Me.Name = "Form1"
        Me.Text = "Hacking for Change"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtRand As TextBox
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Coaltxt As TextBox
    Friend WithEvents etctxt As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents CoalTime As RichTextBox
    Friend WithEvents CoalEffect As RichTextBox
    Friend WithEvents CoalCost As RichTextBox
    Friend WithEvents RichTextBox5 As RichTextBox
    Friend WithEvents SolarEffect As RichTextBox
    Friend WithEvents SolarTime As RichTextBox
    Friend WithEvents OtherCost As RichTextBox
    Friend WithEvents OtherEffect As RichTextBox
    Friend WithEvents OtherTime As RichTextBox
    Friend WithEvents SolarCost As RichTextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox As TextBox
    Friend WithEvents txtInput As RichTextBox
    Friend WithEvents btnConvert As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents LinkLabel1 As LinkLabel
End Class
