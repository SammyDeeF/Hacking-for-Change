﻿Public Class Form1
    'Sub Main()


    'End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox.TextChanged, txtRand.TextChanged

    End Sub

    Private Sub TextBox1_TextChanged_1(sender As Object, e As EventArgs) Handles etctxt.TextChanged

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged_2(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub



    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        txtInput.Focus()
        CoalTime.Text = Val(txtInput.Text) * 1
        CoalEffect.Text = (Val(txtInput.Text) * 30) * (1234.33 / 957)
        CoalCost.Text = (Val(txtInput.Text) * 30) * (13.19 / 100)
        SolarTime.Text = Val(txtInput.Text) * 1
        SolarEffect.Text = Val(CoalEffect.Text) - 250
        SolarCost.Text = Val(txtInput.Text) * 1

    End Sub


    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        CoalTime.Text = ""
        CoalEffect.Text = ""
        CoalCost.Text = ""
        SolarTime.Text = ""
        SolarEffect.Text = ""
        SolarCost.Text = ""
        txtInput.Text = ""
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked

    End Sub


End Class
